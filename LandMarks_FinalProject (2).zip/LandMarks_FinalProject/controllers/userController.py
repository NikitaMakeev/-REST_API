from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session
from models.user import User
from schemas.user import UserCreate, UserLogin
from config.DataB import get_db
from middleware.authJWT import create_access_token, get_current_user
from passlib.context import CryptContext


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# 📌 Хешируем пароль
def hash_password(password: str):
    return pwd_context.hash(password)


# ✅ Проверка пароля
def verify_password(plain_password: str, hashed_password: str):
    return pwd_context.verify(plain_password, hashed_password)


# 📝 Регистрация нового пользователя
def register_user(user_data: UserCreate, db: Session = Depends(get_db)):
    existing_user = db.query(User).filter(User.username == user_data.username).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Пользователь уже существует")

    hashed_pwd = hash_password(user_data.password)
    new_user = User(username=user_data.username, email=user_data.email, password=hashed_pwd)

    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user


# 🔑 Логин + JWT
def login_user(login_data: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == login_data.username).first()

    if not user or not verify_password(login_data.password, user.password):
        raise HTTPException(status_code=401, detail="Неверный логин или пароль")

    token = create_access_token(data={"sub": user.username})
    return {"access_token": token, "token_type": "bearer"}


# 👤 Получение текущего пользователя (по токену)
def get_current_user_info(current_user: User = Depends(get_current_user)):
    return current_user
