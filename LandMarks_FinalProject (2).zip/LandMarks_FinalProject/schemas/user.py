from pydantic import BaseModel, EmailStr
from typing import Optional


# 🔐 Схема для входа в систему (логин)
class UserLogin(BaseModel):
    username: str
    password: str


# 📝 Схема для регистрации
class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str


# 👤 Схема ответа (без пароля)
class UserResponse(BaseModel):
    id: int
    username: str
    email: EmailStr

    class Config:
        orm_mode = True


# 🎟️ JWT-токен
class Token(BaseModel):
    access_token: str
    token_type: str


# 🧾 Декодированная информация из токена
class TokenData(BaseModel):
    username: Optional[str] = None
