# models/__init__.py

from .user import User
from .landmark import Landmark